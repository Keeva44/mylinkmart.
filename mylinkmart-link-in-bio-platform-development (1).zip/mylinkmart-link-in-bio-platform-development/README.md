# MyLinkMart - Modern Link-in-Bio + Affiliate Store Builder

A **fully modern, user-friendly** link-in-bio and affiliate store builder with advanced features, beautiful animations, and seamless deployment support.

## 🚀 What's New in v2.0

- ✨ **Modern UI/UX** with Framer Motion animations
- 📱 **Drag & Drop** image uploads with progress tracking
- 🎨 **Enhanced Builder** with tabbed interface
- 🚀 **Faster Performance** with optimized components
- 📊 **Live Preview** while building
- 🎯 **Better Validation** and error handling
- 📱 **Mobile-First** responsive design

## 🛠️ Tech Stack

- **React 18** with modern hooks
- **Framer Motion** for animations
- **React Router v7** for navigation
- **Tailwind CSS** for styling
- **Font Awesome & React Icons**
- **Local Storage** for data persistence
- **Vite** for lightning-fast builds

## 🏃‍♂️ Quick Start

### Development

```bash
# Clone and install
git clone <repository-url>
cd mylinkmart
npm install

# Start development server
npm run dev
```

### Building for Production

```bash
# Build optimized version
npm run build

# Preview build locally
npm run preview
```

### Deployment

#### Netlify (Recommended)
1. Connect your repository to Netlify
2. Build command: `npm run build`
3. Publish directory: `dist`
4. Deploy! 🎉

#### GitHub Pages
```bash
npm run build
 Deploy the `dist` folder to your GitHub Pages repository
```

#### Vercel, Railway, or any static host
- Import repository
- Set build command: `npm run build`
- Set output directory: `dist`

## 🎯 Features

### 🛍️ Store Builder
- **Tabbed Interface**: Organized sections for better UX
- **Drag & Drop**: Upload images by dragging or clicking
- **Progress Tracking**: Visual feedback during uploads
- **Live Preview**: See changes in real-time
- **Form Validation**: Smart validation with helpful error messages
- **Auto-save**: Prevent data loss with smart storage

### 🎨 Design & Themes
- **4 Beautiful Themes**: Light, Dark, Minimal, Gradient
- **Custom Colors**: Full color customization
- **Responsive Design**: Perfect on all devices
- **Smooth Animations**: Professional micro-interactions
- **Modern UI**: Clean, intuitive interface

### 📱 Store Display
- **Mobile Optimized**: Perfect for mobile browsers
- **Social Media Icons**: Beautiful hover effects
- **Product Cards**: Clean product presentation
- **Share Functionality**: Easy sharing with one click
- **SEO Friendly**: Proper meta tags and structure

### 🔧 Technical Features
- **No Backend**: 100% frontend, works anywhere
- **Local Storage**: Persistent data storage
- **Export HTML**: Download static files
- **PWA Ready**: Works offline after first load
- **Fast Loading**: Optimized for performance

## 📁 Project Structure

```
src/
├── components/           # Reusable components
│   ├── Header.jsx       # Navigation with mobile menu
│   ├── Footer.jsx       # Animated footer
│   ├── DonationModal.jsx # Support modal
│   └── Toast.jsx        # Notifications
├── common/              # Common utilities
│   └── SafeIcon.jsx     # Safe icon rendering
├── pages/               # Main pages
│   ├── LandingPage.jsx  # Hero and features
│   ├── BuilderPage.jsx  # Store creation
│   └── StorePage.jsx    # Store display
├── App.jsx              # Main app component
├── App.css              # Custom styles
└── main.jsx             # App entry point
```

## 🎨 Customization

### Adding New Themes
1. Add theme class to `App.css`
2. Update `getThemeClasses()` in `StorePage.jsx`
3. Add theme option to builder

### Adding Social Platforms
1. Update `socialLinks` object in `BuilderPage.jsx`
2. Add icon mapping in `StorePage.jsx`
3. Update CSS classes for hover effects

### Custom Colors
Edit the gradient definitions in `App.css`:
```css
.gradient-bg {
  background: linear-gradient(135deg, #your-color-1 0%, #your-color-2 100%);
}
```

## 🔗 API & Storage

### Local Storage Structure
```javascript
{
  "mylinkmart_stores": {
    "username": {
      username: "string",
      profileImage: "data:image/...",
      bannerImage: "data:image/...",
      bio: "string",
      products: [...],
      socialLinks: {...},
      theme: "light|dark|minimal|gradient",
      accentColor: "#hexcode"
    }
  }
}
```

### Export Format
Generates a single HTML file with:
- Inlined CSS and styles
- Base64 encoded images
- Responsive design
- SEO meta tags

## 🚀 Performance Optimizations

- **Code Splitting**: Automatic with Vite
- **Tree Shaking**: Unused code eliminated
- **Image Optimization**: WebP support when available
- **Lazy Loading**: Components load as needed
- **Minification**: Production builds are optimized
- **Gzip Ready**: Compression headers configured

## 📱 Browser Support

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+
- Mobile Safari iOS 14+
- Chrome Mobile 90+

## 🐛 Troubleshooting

### Common Issues

**Store not loading?**
- Check browser localStorage in dev tools
- Ensure browser supports localStorage
- Clear cache and reload

**Images not uploading?**
- Check file size (max 5MB)
- Ensure image format is supported
- Check browser file permissions

**Build failing?**
- Run `npm run lint` to check for errors
- Ensure Node.js 18+ is installed
- Clear node_modules and reinstall

### Debug Mode
Add `?debug=true` to URL for additional logging.

## 🔒 Security

- **No Data Collection**: Everything stays in your browser
- **HTTPS Required**: For production deployment
- **CSP Ready**: Content Security Policy compatible
- **XSS Protected**: Input sanitization included

## 📄 License

MIT License - Feel free to use commercially!

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing`)
5. Open Pull Request

## 💬 Support

- 📧 Create an issue on GitHub
- 🎉 Support the project via the donation modal
- 📖 Check this README for common issues

---

<div align="center">
  <strong>Built with ❤️ using MyLinkMart</strong><br>
  <em>Help keep this free for creators worldwide!</em>
</div>