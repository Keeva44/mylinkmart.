import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';

const LandingPage = () => {
  const features = [
    {
      icon: FiIcons.FiShoppingBag,
      title: 'Affiliate Products',
      description: 'Add unlimited affiliate products with images, descriptions, and direct links to boost your earnings.',
      color: 'from-blue-500 to-blue-600'
    },
    {
      icon: FiIcons.FiPalette,
      title: 'Custom Themes',
      description: 'Choose from beautiful themes or customize colors to match your brand perfectly.',
      color: 'from-purple-500 to-purple-600'
    },
    {
      icon: FiIcons.FiShare2,
      title: 'Social Media Links',
      description: 'Connect all your social profiles with beautiful icons that match your brand.',
      color: 'from-pink-500 to-pink-600'
    },
    {
      icon: FiIcons.FiSmartphone,
      title: 'Mobile Optimized',
      description: 'Your store looks perfect on all devices with responsive design out of the box.',
      color: 'from-green-500 to-green-600'
    },
    {
      icon: FiIcons.FiDownload,
      title: 'Export HTML',
      description: 'Download your store as static HTML files to host anywhere - GitHub Pages, Netlify, or your own server.',
      color: 'from-yellow-500 to-yellow-600'
    },
    {
      icon: FiIcons.FiInfinite,
      title: 'Free Forever',
      description: 'No monthly fees, no limits. Create and manage your link-in-bio stores completely free.',
      color: 'from-red-500 to-red-600'
    }
  ];

  const steps = [
    {
      number: '1',
      title: 'Create Your Store',
      description: 'Fill in your profile, add products, and customize your theme in our easy-to-use builder.',
      icon: FiIcons.FiEdit
    },
    {
      number: '2',
      title: 'Share Your Link',
      description: 'Get your unique store URL and share it in your bio, stories, or anywhere you want.',
      icon: FiIcons.FiShare
    },
    {
      number: '3',
      title: 'Start Earning',
      description: 'When visitors click your affiliate links, you earn commissions. It\'s that simple!',
      icon: FiIcons.FiDollarSign
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600">
        <div className="absolute inset-0 bg-black opacity-10"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <motion.h1 
              className="text-4xl md:text-6xl font-bold text-white mb-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              Turn Your Bio Into a<br />
              <span className="text-yellow-300">Mini Affiliate Store</span>
            </motion.h1>
            
            <motion.p 
              className="text-xl md:text-2xl mb-8 text-blue-100 max-w-3xl mx-auto"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
            >
              Create beautiful link-in-bio pages with affiliate products, social links, and more. 
              <strong className="text-yellow-300"> Free Forever.</strong>
            </motion.p>
            
            <motion.div 
              className="flex flex-col sm:flex-row gap-4 justify-center items-center"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
            >
              <Link 
                to="/builder" 
                className="group bg-yellow-400 hover:bg-yellow-500 text-gray-900 font-bold py-4 px-8 rounded-xl text-lg transition-all duration-200 transform hover:scale-105 flex items-center space-x-2 shadow-lg"
              >
                <SafeIcon icon={FiIcons.FiShoppingBag} />
                <span>Create Your Store</span>
                <SafeIcon icon={FiIcons.FiArrowRight} className="group-hover:translate-x-1 transition-transform" />
              </Link>
              
              <button className="group bg-white bg-opacity-20 hover:bg-opacity-30 backdrop-blur-sm text-white font-semibold py-4 px-8 rounded-xl text-lg transition-all duration-200 transform hover:scale-105 flex items-center space-x-2 border border-white border-opacity-30">
                <SafeIcon icon={FiIcons.FiHeart} className="text-pink-300" />
                <span>Support MyLinkMart</span>
              </button>
            </motion.div>
          </motion.div>

          {/* Floating Elements */}
          <motion.div
            animate={{ y: [-10, 10, -10] }}
            transition={{ duration: 3, repeat: Infinity }}
            className="absolute top-20 left-10 w-20 h-20 bg-yellow-400 rounded-full opacity-20 blur-xl"
          />
          <motion.div
            animate={{ y: [10, -10, 10] }}
            transition={{ duration: 3, repeat: Infinity, delay: 1 }}
            className="absolute bottom-20 right-10 w-32 h-32 bg-pink-400 rounded-full opacity-20 blur-xl"
          />
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
              Everything You Need in One Place
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Build professional link-in-bio pages with powerful features that help you monetize your audience.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ y: -5 }}
                className="text-center"
              >
                <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-8 hover:shadow-2xl transition-all duration-300">
                  <div className={`w-16 h-16 bg-gradient-to-r ${feature.color} rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg`}>
                    <SafeIcon icon={feature.icon} className="text-white text-2xl" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-800 mb-3">{feature.title}</h3>
                  <p className="text-gray-600 leading-relaxed">{feature.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
              How It Works
            </h2>
            <p className="text-xl text-gray-600">
              Get your affiliate store up and running in just 3 simple steps
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {steps.map((step, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: index % 2 === 0 ? -30 : 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.2 }}
                className="text-center"
              >
                <div className="relative mb-6">
                  <motion.div
                    whileHover={{ scale: 1.1 }}
                    className="w-20 h-20 bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg"
                  >
                    <SafeIcon icon={step.icon} className="text-white text-2xl" />
                  </motion.div>
                  <motion.div
                    animate={{ scale: [1, 1.1, 1] }}
                    transition={{ duration: 2, repeat: Infinity, delay: index * 0.5 }}
                    className="absolute -top-2 -right-2 w-8 h-8 bg-yellow-400 rounded-full flex items-center justify-center shadow-lg"
                  >
                    <span className="text-gray-900 font-bold text-sm">{step.number}</span>
                  </motion.div>
                </div>
                <h3 className="text-xl font-semibold text-gray-800 mb-3">{step.title}</h3>
                <p className="text-gray-600 leading-relaxed">{step.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 relative overflow-hidden">
        <div className="absolute inset-0 bg-black opacity-10"></div>
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
              Ready to Start Your Affiliate Journey?
            </h2>
            <p className="text-xl mb-8 text-blue-100">
              Join thousands of creators who are already monetizing their audience with MyLinkMart.
            </p>
            <Link 
              to="/builder" 
              className="group inline-flex items-center space-x-2 bg-yellow-400 hover:bg-yellow-500 text-gray-900 font-bold py-4 px-8 rounded-xl text-lg transition-all duration-200 transform hover:scale-105 shadow-xl"
            >
              <SafeIcon icon={FiIcons.FiRocket} />
              <span>Create Your Store Now - It's Free!</span>
              <SafeIcon icon={FiIcons.FiArrowRight} className="group-hover:translate-x-1 transition-transform" />
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { number: '10K+', label: 'Active Stores' },
              { number: '50K+', label: 'Products Listed' },
              { number: '100K+', label: 'Monthly Visitors' },
              { number: '$0', label: 'Monthly Cost' }
            ].map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="text-center"
              >
                <h3 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2">
                  {stat.number}
                </h3>
                <p className="text-gray-600">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default LandingPage;