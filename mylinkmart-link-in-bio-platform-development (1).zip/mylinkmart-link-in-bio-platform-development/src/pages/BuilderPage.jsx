import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';

const BuilderPage = ({ showToast }) => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('basic');
  const [isSaving, setIsSaving] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [uploadProgress, setUploadProgress] = useState({});
  
  const [formData, setFormData] = useState({
    username: '',
    profileImage: '',
    bannerImage: '',
    bio: '',
    products: [],
    socialLinks: {
      twitter: '',
      instagram: '',
      facebook: '',
      linkedin: '',
      tiktok: '',
      youtube: '',
      pinterest: '',
      github: '',
      telegram: '',
      whatsapp: '',
      spotify: ''
    },
    theme: 'light',
    accentColor: '#3B82F6'
  });

  const [newProduct, setNewProduct] = useState({
    name: '',
    url: '',
    description: '',
    image: '',
    price: ''
  });

  const [editingProductIndex, setEditingProductIndex] = useState(-1);
  const [validationErrors, setValidationErrors] = useState({});

  const tabs = [
    { id: 'basic', label: 'Basic Info', icon: FiIcons.FiUser },
    { id: 'products', label: 'Products', icon: FiIcons.FiShoppingBag },
    { id: 'social', label: 'Social Links', icon: FiIcons.FiShare2 },
    { id: 'theme', label: 'Theme', icon: FiIcons.FiPalette }
  ];

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const editUsername = urlParams.get('edit');
    if (editUsername) {
      const stores = JSON.parse(localStorage.getItem('mylinkmart_stores') || '{}');
      if (stores[editUsername]) {
        setFormData(stores[editUsername]);
        showToast('Store loaded for editing');
      }
    }
  }, []);

  const validateField = (name, value) => {
    let error = '';
    
    if (name === 'username') {
      if (!value) error = 'Username is required';
      else if (!/^[a-zA-Z0-9_-]+$/.test(value)) {
        error = 'Username can only contain letters, numbers, hyphens, and underscores';
      } else if (value.length < 3) {
        error = 'Username must be at least 3 characters';
      }
    }
    
    if (name === 'url' && value) {
      try {
        new URL(value);
      } catch {
        error = 'Please enter a valid URL';
      }
    }
    
    setValidationErrors(prev => ({ ...prev, [name]: error }));
    return !error;
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    validateField(name, value);
  };

  const handleSocialChange = (platform, value) => {
    setFormData(prev => ({
      ...prev,
      socialLinks: {
        ...prev.socialLinks,
        [platform]: value
      }
    }));
  };

  const handleImageUpload = useCallback(async (field, file) => {
    if (!file) return;
    
    // Simulate upload progress
    const progressKey = `${field}_${Date.now()}`;
    setUploadProgress(prev => ({ ...prev, [progressKey]: 0 }));
    
    // Validate file
    if (!file.type.startsWith('image/')) {
      showToast('Please upload an image file', 'error');
      return;
    }
    
    if (file.size > 5 * 1024 * 1024) { // 5MB limit
      showToast('Image size must be less than 5MB', 'error');
      return;
    }
    
    // Simulate upload progress
    for (let i = 0; i <= 100; i += 20) {
      await new Promise(resolve => setTimeout(resolve, 100));
      setUploadProgress(prev => ({ ...prev, [progressKey]: i }));
    }
    
    const reader = new FileReader();
    reader.onload = (e) => {
      setFormData(prev => ({ ...prev, [field]: e.target.result }));
      setUploadProgress(prev => {
        const newProgress = { ...prev };
        delete newProgress[progressKey];
        return newProgress;
      });
      showToast('Image uploaded successfully!');
    };
    reader.readAsDataURL(file);
  }, [showToast]);

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e, field) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleImageUpload(field, e.dataTransfer.files[0]);
    }
  };

  const addProduct = () => {
    if (!validateField('productName', newProduct.name)) {
      showToast('Please enter a valid product name', 'error');
      return;
    }
    
    if (!validateField('url', newProduct.url)) {
      showToast('Please enter a valid affiliate URL', 'error');
      return;
    }

    const product = { ...newProduct, id: Date.now() };
    
    if (editingProductIndex >= 0) {
      const updatedProducts = [...formData.products];
      updatedProducts[editingProductIndex] = product;
      setFormData(prev => ({ ...prev, products: updatedProducts }));
      setEditingProductIndex(-1);
      showToast('Product updated successfully!');
    } else {
      setFormData(prev => ({
        ...prev,
        products: [...prev.products, product]
      }));
      showToast('Product added successfully!');
    }
    
    setNewProduct({ name: '', url: '', description: '', image: '', price: '' });
  };

  const editProduct = (index) => {
    setNewProduct(formData.products[index]);
    setEditingProductIndex(index);
    setActiveTab('products');
  };

  const removeProduct = (index) => {
    setFormData(prev => ({
      ...prev,
      products: prev.products.filter((_, i) => i !== index)
    }));
    showToast('Product removed');
  };

  const validateUsername = (username) => {
    const stores = JSON.parse(localStorage.getItem('mylinkmart_stores') || '{}');
    return !stores[username] || stores[username].username === formData.username;
  };

  const saveStore = async () => {
    // Validate all required fields
    if (!formData.username) {
      showToast('Please enter a username', 'error');
      setActiveTab('basic');
      return;
    }

    if (!validateUsername(formData.username)) {
      showToast('Username already taken', 'error');
      setActiveTab('basic');
      return;
    }

    if (formData.products.length === 0) {
      showToast('Please add at least one product', 'error');
      setActiveTab('products');
      return;
    }

    setIsSaving(true);
    
    // Simulate save delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const stores = JSON.parse(localStorage.getItem('mylinkmart_stores') || '{}');
    stores[formData.username] = formData;
    localStorage.setItem('mylinkmart_stores', JSON.stringify(stores));
    
    setIsSaving(false);
    showToast('Store saved successfully!');
  };

  const previewStore = () => {
    if (!formData.username) {
      showToast('Please save your store first', 'error');
      return;
    }
    window.open(`#/store/${formData.username}`, '_blank');
  };

  const exportHTML = () => {
    if (!formData.username) {
      showToast('Please save your store first', 'error');
      return;
    }

    const html = generateStaticHTML(formData);
    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${formData.username}-store.html`;
    a.click();
    URL.revokeObjectURL(url);
    
    showToast('HTML file exported successfully!');
  };

  const generateStaticHTML = (data) => {
    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${data.username} - MyLinkMart Store</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        .social-icons { display: flex; flex-wrap: wrap; gap: 15px; justify-content: center; margin: 20px 0; }
        .social-icons a { display: flex; align-items: center; justify-content: center; width: 45px; height: 45px; background-color: #f0f0f0; color: #333; border-radius: 50%; font-size: 20px; transition: all 0.3s ease; text-decoration: none; }
        .social-icons a.twitter:hover { background-color: #1DA1F2; color: white; }
        .social-icons a.instagram:hover { background-color: #E1306C; color: white; }
        .social-icons a.facebook:hover { background-color: #1877F2; color: white; }
        .social-icons a.linkedin:hover { background-color: #0A66C2; color: white; }
        .social-icons a.tiktok:hover { background-color: #010101; color: white; }
        .social-icons a.youtube:hover { background-color: #FF0000; color: white; }
        .social-icons a.whatsapp:hover { background-color: #25D366; color: white; }
        .theme-${data.theme} { ${getThemeStyles(data.theme)} }
        .product-card { transition: all 0.3s ease; }
        .product-card:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(0,0,0,0.15); }
        [data-theme-accent] { color: ${data.accentColor}; }
        [data-theme-bg] { background-color: ${data.accentColor}; }
    </style>
</head>
<body class="theme-${data.theme}">
    <div class="min-h-screen py-8">
        <div class="max-w-md mx-auto">
            <div class="rounded-xl shadow-xl overflow-hidden">
                ${data.bannerImage ? `<div class="h-48 bg-cover bg-center" style="background-image: url('${data.bannerImage}')"></div>` : ''}
                
                <div class="p-6 text-center">
                    ${data.profileImage ? `<img src="${data.profileImage}" alt="Profile" class="w-24 h-24 rounded-full mx-auto mb-4 border-4 border-white shadow-lg ${data.bannerImage ? '-mt-16' : ''}">` : ''}
                    
                    <h1 class="text-2xl font-bold mb-2">@${data.username}</h1>
                    ${data.bio ? `<p class="text-gray-600 mb-6">${data.bio}</p>` : ''}
                    
                    ${generateSocialLinksHTML(data.socialLinks)}
                    
                    <div class="space-y-3 mt-6">
                        ${data.products.map(product => `
                            <a href="${product.url}" target="_blank" class="product-card block bg-gray-50 hover:bg-gray-100 rounded-lg p-4">
                                <div class="flex items-center space-x-3">
                                    ${product.image ? `<img src="${product.image}" alt="${product.name}" class="w-12 h-12 rounded-lg object-cover">` : '<div class="w-12 h-12 bg-gray-300 rounded-lg flex items-center justify-center"><i class="fas fa-box text-gray-500"></i></div>'}
                                    <div class="flex-1 text-left">
                                        <h3 class="font-semibold text-gray-800">${product.name}</h3>
                                        ${product.description ? `<p class="text-sm text-gray-600">${product.description}</p>` : ''}
                                        ${product.price ? `<p class="text-sm font-semibold" data-theme-accent>${product.price}</p>` : ''}
                                    </div>
                                    <i class="fas fa-external-link-alt text-gray-400"></i>
                                </div>
                            </a>
                        `).join('')}
                    </div>
                </div>
                
                <div class="bg-gray-50 px-6 py-4 text-center">
                    <p class="text-sm text-gray-500">Built with ❤️ using <a href="#" class="text-blue-600 hover:underline">MyLinkMart</a></p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>`;
  };

  const generateSocialLinksHTML = (socialLinks) => {
    const platforms = [
      { key: 'twitter', icon: 'fab fa-twitter', class: 'twitter' },
      { key: 'instagram', icon: 'fab fa-instagram', class: 'instagram' },
      { key: 'facebook', icon: 'fab fa-facebook-f', class: 'facebook' },
      { key: 'linkedin', icon: 'fab fa-linkedin-in', class: 'linkedin' },
      { key: 'tiktok', icon: 'fab fa-tiktok', class: 'tiktok' },
      { key: 'youtube', icon: 'fab fa-youtube', class: 'youtube' },
      { key: 'whatsapp', icon: 'fab fa-whatsapp', class: 'whatsapp' }
    ];

    const links = platforms
      .filter(platform => socialLinks[platform.key])
      .map(platform => `
        <a href="${socialLinks[platform.key]}" class="${platform.class}" target="_blank" aria-label="${platform.key}">
          <i class="${platform.icon}"></i>
        </a>
      `).join('');

    return links ? `<div class="social-icons">${links}</div>` : '';
  };

  const getThemeStyles = (theme) => {
    switch (theme) {
      case 'dark':
        return 'background-color: #1f2937; color: white;';
      case 'minimal':
        return 'background-color: #f9fafb; color: #374151;';
      case 'gradient':
        return 'background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;';
      default:
        return 'background-color: white; color: #1f2937;';
    }
  };

  const UploadArea = ({ field, label, currentImage }) => (
    <motion.div
      className={`relative border-2 border-dashed rounded-lg p-6 text-center transition-all duration-200 ${
        dragActive ? 'border-blue-500 bg-blue-50' : 'border-gray-300 hover:border-gray-400'
      }`}
      onDragEnter={handleDrag}
      onDragLeave={handleDrag}
      onDragOver={handleDrag}
      onDrop={(e) => handleDrop(e, field)}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
    >
      {currentImage && (
        <div className="mb-4">
          <img 
            src={currentImage} 
            alt="Preview" 
            className="w-24 h-24 mx-auto rounded-lg object-cover"
          />
        </div>
      )}
      
      <SafeIcon icon={FiIcons.FiUploadCloud} className="w-12 h-12 mx-auto text-gray-400 mb-4" />
      
      <p className="text-sm font-medium text-gray-600 mb-2">
        {currentImage ? 'Click to replace or drag new image' : `Upload ${label}`}
      </p>
      
      <p className="text-xs text-gray-500 mb-4">
        PNG, JPG, GIF up to 5MB
      </p>
      
      <input
        type="file"
        accept="image/*"
        onChange={(e) => e.target.files[0] && handleImageUpload(field, e.target.files[0])}
        className="hidden"
        id={`${field}-upload`}
      />
      
      <label
        htmlFor={`${field}-upload`}
        className="inline-flex items-center px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 cursor-pointer transition-colors duration-200"
      >
        <SafeIcon icon={FiIcons.FiUpload} className="mr-2" />
        Choose File
      </label>
      
      {Object.entries(uploadProgress).filter(([key]) => key.includes(field)).map(([key, progress]) => (
        <div key={key} className="mt-4">
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="bg-blue-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${progress}%` }}
            ></div>
          </div>
          <p className="text-xs text-gray-500 mt-1">Uploading... {progress}%</p>
        </div>
      ))}
    </motion.div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <h1 className="text-4xl font-bold text-gray-800 mb-2">
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Store Builder
            </span>
          </h1>
          <p className="text-gray-600">Create your beautiful link-in-bio store</p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-white rounded-2xl shadow-xl p-6"
            >
              {/* Tabs */}
              <div className="flex flex-wrap gap-2 mb-6 border-b">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex items-center space-x-2 px-4 py-3 font-medium transition-all duration-200 border-b-2 ${
                      activeTab === tab.id
                        ? 'text-blue-600 border-blue-600'
                        : 'text-gray-500 border-transparent hover:text-gray-700'
                    }`}
                  >
                    <SafeIcon icon={tab.icon} className="w-4 h-4" />
                    <span>{tab.label}</span>
                  </button>
                ))}
              </div>

              {/* Tab Content */}
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeTab}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.2 }}
                >
                  {activeTab === 'basic' && (
                    <div className="space-y-6">
                      <div>
                        <label className="form-label">Username *</label>
                        <div className="relative">
                          <input
                            type="text"
                            name="username"
                            value={formData.username}
                            onChange={handleInputChange}
                            className={`form-input pr-12 ${validationErrors.username ? 'border-red-500' : ''}`}
                            placeholder="your-username"
                          />
                          <SafeIcon icon={FiIcons.FiUser} className="absolute right-3 top-3 w-5 h-5 text-gray-400" />
                        </div>
                        {validationErrors.username && (
                          <p className="text-red-500 text-sm mt-1">{validationErrors.username}</p>
                        )}
                        {formData.username && (
                          <p className="text-sm text-gray-500 mt-1">
                            Your store URL: <span className="font-mono bg-gray-100 px-2 py-1 rounded">store/{formData.username}</span>
                          </p>
                        )}
                      </div>

                      <div>
                        <label className="form-label">Profile Image</label>
                        <UploadArea field="profileImage" label="Profile Picture" currentImage={formData.profileImage} />
                      </div>

                      <div>
                        <label className="form-label">Banner Image (Optional)</label>
                        <UploadArea field="bannerImage" label="Banner" currentImage={formData.bannerImage} />
                      </div>

                      <div>
                        <label className="form-label">Bio</label>
                        <textarea
                          name="bio"
                          value={formData.bio}
                          onChange={handleInputChange}
                          className="form-input"
                          rows="4"
                          placeholder="Tell your visitors about yourself..."
                          maxLength={500}
                        />
                        <p className="text-xs text-gray-500 mt-1">{formData.bio.length}/500 characters</p>
                      </div>
                    </div>
                  )}

                  {activeTab === 'products' && (
                    <div className="space-y-6">
                      {/* Product Form */}
                      <div className="bg-gray-50 rounded-xl p-6">
                        <h3 className="text-lg font-semibold mb-4">
                          {editingProductIndex >= 0 ? 'Edit Product' : 'Add New Product'}
                        </h3>
                        
                        <div className="space-y-4">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                              <label className="form-label">Product Name *</label>
                              <input
                                type="text"
                                value={newProduct.name}
                                onChange={(e) => setNewProduct(prev => ({ ...prev, name: e.target.value }))}
                                className="form-input"
                                placeholder="Product name"
                              />
                            </div>
                            <div>
                              <label className="form-label">Affiliate URL *</label>
                              <input
                                type="url"
                                value={newProduct.url}
                                onChange={(e) => setNewProduct(prev => ({ ...prev, url: e.target.value }))}
                                className="form-input"
                                placeholder="https://..."
                              />
                            </div>
                          </div>
                          
                          <div>
                            <label className="form-label">Description</label>
                            <textarea
                              value={newProduct.description}
                              onChange={(e) => setNewProduct(prev => ({ ...prev, description: e.target.value }))}
                              className="form-input"
                              rows="3"
                              placeholder="Product description..."
                            />
                          </div>
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                              <label className="form-label">Product Image URL</label>
                              <input
                                type="url"
                                value={newProduct.image}
                                onChange={(e) => setNewProduct(prev => ({ ...prev, image: e.target.value }))}
                                className="form-input"
                                placeholder="https://..."
                              />
                            </div>
                            <div>
                              <label className="form-label">Price</label>
                              <input
                                type="text"
                                value={newProduct.price}
                                onChange={(e) => setNewProduct(prev => ({ ...prev, price: e.target.value }))}
                                className="form-input"
                                placeholder="$29.99"
                              />
                            </div>
                          </div>
                          
                          <div className="flex gap-3">
                            <motion.button
                              whileHover={{ scale: 1.02 }}
                              whileTap={{ scale: 0.98 }}
                              onClick={addProduct}
                              className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-200"
                            >
                              <SafeIcon icon={editingProductIndex >= 0 ? FiIcons.FiSave : FiIcons.FiPlus} className="mr-2" />
                              {editingProductIndex >= 0 ? 'Update Product' : 'Add Product'}
                            </motion.button>
                            {editingProductIndex >= 0 && (
                              <motion.button
                                whileHover={{ scale: 1.02 }}
                                whileTap={{ scale: 0.98 }}
                                onClick={() => {
                                  setEditingProductIndex(-1);
                                  setNewProduct({ name: '', url: '', description: '', image: '', price: '' });
                                }}
                                className="px-6 py-3 bg-gray-200 hover:bg-gray-300 text-gray-800 font-semibold rounded-lg transition-all duration-200"
                              >
                                Cancel
                              </motion.button>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Products List */}
                      <div>
                        <h3 className="text-lg font-semibold mb-4">Products ({formData.products.length})</h3>
                        
                        {formData.products.length === 0 ? (
                          <div className="text-center py-12 bg-gray-50 rounded-lg">
                            <SafeIcon icon={FiIcons.FiShoppingBag} className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                            <p className="text-gray-500">No products yet. Add your first product above!</p>
                          </div>
                        ) : (
                          <div className="space-y-3 max-h-96 overflow-y-auto">
                            {formData.products.map((product, index) => (
                              <motion.div
                                key={product.id}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                className="bg-white border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow duration-200"
                              >
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center space-x-4 flex-1">
                                    {product.image ? (
                                      <img src={product.image} alt={product.name} className="w-12 h-12 rounded-lg object-cover" />
                                    ) : (
                                      <div className="w-12 h-12 bg-gray-200 rounded-lg flex items-center justify-center">
                                        <SafeIcon icon={FiIcons.FiBox} className="w-6 h-6 text-gray-400" />
                                      </div>
                                    )}
                                    <div className="flex-1">
                                      <h4 className="font-semibold text-gray-800">{product.name}</h4>
                                      <div className="flex items-center space-x-3 text-sm text-gray-500">
                                        {product.price && <span className="font-medium">{product.price}</span>}
                                        <a href={product.url} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">
                                          View Link
                                        </a>
                                      </div>
                                    </div>
                                  </div>
                                  
                                  <div className="flex space-x-2">
                                    <motion.button
                                      whileHover={{ scale: 1.1 }}
                                      whileTap={{ scale: 0.9 }}
                                      onClick={() => editProduct(index)}
                                      className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors duration-200"
                                    >
                                      <SafeIcon icon={FiIcons.FiEdit2} className="w-4 h-4" />
                                    </motion.button>
                                    <motion.button
                                      whileHover={{ scale: 1.1 }}
                                      whileTap={{ scale: 0.9 }}
                                      onClick={() => removeProduct(index)}
                                      className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors duration-200"
                                    >
                                      <SafeIcon icon={FiIcons.FiTrash2} className="w-4 h-4" />
                                    </motion.button>
                                  </div>
                                </div>
                              </motion.div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {activeTab === 'social' && (
                    <div className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {Object.entries(formData.socialLinks).map(([platform, url]) => (
                          <motion.div
                            key={platform}
                            whileHover={{ scale: 1.02 }}
                            className="bg-gray-50 rounded-lg p-4"
                          >
                            <label className="form-label capitalize flex items-center space-x-2">
                              <SafeIcon icon={FiIcons[`Fi${platform.charAt(0).toUpperCase()}${platform.slice(1)}`]} className="w-4 h-4" />
                              <span>{platform}</span>
                            </label>
                            <input
                              type="url"
                              value={url}
                              onChange={(e) => handleSocialChange(platform, e.target.value)}
                              className="form-input"
                              placeholder={`Your ${platform} URL`}
                            />
                          </motion.div>
                        ))}
                      </div>
                    </div>
                  )}

                  {activeTab === 'theme' && (
                    <div className="space-y-6">
                      <div>
                        <label className="form-label">Theme Style</label>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                          {[
                            { value: 'light', label: 'Light', bg: 'bg-white border-gray-300' },
                            { value: 'dark', label: 'Dark', bg: 'bg-gray-900' },
                            { value: 'minimal', label: 'Minimal', bg: 'bg-gray-50 border-gray-300' },
                            { value: 'gradient', label: 'Gradient', bg: 'gradient-bg' }
                          ].map((theme) => (
                            <motion.button
                              key={theme.value}
                              whileHover={{ scale: 1.05 }}
                              whileTap={{ scale: 0.95 }}
                              onClick={() => handleInputChange({ target: { name: 'theme', value: theme.value } })}
                              className={`relative h-24 rounded-lg ${theme.bg} border-2 transition-all duration-200 ${
                                formData.theme === theme.value ? 'border-blue-500 shadow-lg' : 'border-gray-200'
                              }`}
                            >
                              <span className={`text-sm font-medium ${
                                theme.value === 'dark' || theme.value === 'gradient' ? 'text-white' : 'text-gray-800'
                              }`}>
                                {theme.label}
                              </span>
                              {formData.theme === theme.value && (
                                <div className="absolute top-2 right-2">
                                  <div className="w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center">
                                    <SafeIcon icon={FiIcons.FiCheck} className="w-3 h-3 text-white" />
                                  </div>
                                </div>
                              )}
                            </motion.button>
                          ))}
                        </div>
                      </div>
                      
                      <div>
                        <label className="form-label">Accent Color</label>
                        <div className="flex items-center space-x-4">
                          <input
                            type="color"
                            name="accentColor"
                            value={formData.accentColor}
                            onChange={handleInputChange}
                            className="h-12 w-24 rounded-lg border-2 border-gray-300 cursor-pointer"
                          />
                          <input
                            type="text"
                            value={formData.accentColor}
                            onChange={(e) => setFormData(prev => ({ ...prev, accentColor: e.target.value }))}
                            className="form-input flex-1"
                            placeholder="#3B82F6"
                          />
                        </div>
                      </div>
                    </div>
                  )}
                </motion.div>
              </AnimatePresence>
            </motion.div>
          </div>

          {/* Preview Sidebar */}
          <div className="lg:col-span-1">
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="sticky top-8 space-y-6"
            >
              {/* Live Preview */}
              <div className="bg-white rounded-2xl shadow-xl p-6">
                <h3 className="text-lg font-semibold mb-4">Live Preview</h3>
                
                <div className={`theme-${formData.theme} rounded-lg p-6 border-2 border-gray-200 min-h-[400px]`}>
                  {formData.bannerImage && (
                    <div className="h-24 bg-cover bg-center rounded-lg mb-4" style={{ backgroundImage: `url(${formData.bannerImage})` }}></div>
                  )}
                  
                  <div className="text-center">
                    {formData.profileImage && (
                      <img src={formData.profileImage} alt="Profile" className="w-16 h-16 rounded-full mx-auto mb-3 border-2 border-white shadow-lg" />
                    )}
                    
                    <h4 className="text-lg font-bold mb-2">@{formData.username || 'username'}</h4>
                    {formData.bio && <p className="text-sm text-gray-600 mb-4">{formData.bio}</p>}
                    
                    {/* Social Links Preview */}
                    {Object.entries(formData.socialLinks).some(([, url]) => url) && (
                      <div className="flex justify-center space-x-2 mb-4">
                        {Object.entries(formData.socialLinks).slice(0, 4).map(([platform, url]) => 
                          url && (
                            <div key={platform} className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
                              <i className={`fab fa-${platform} text-xs`}></i>
                            </div>
                          )
                        )}
                        {Object.entries(formData.socialLinks).filter(([, url]) => url).length > 4 && (
                          <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
                            <span className="text-xs">+{Object.entries(formData.socialLinks).filter(([, url]) => url).length - 4}</span>
                          </div>
                        )}
                      </div>
                    )}
                    
                    {/* Products Preview */}
                    <div className="space-y-2">
                      {formData.products.slice(0, 3).map((product, index) => (
                        <div key={index} className="bg-gray-100 rounded-lg p-3 text-left">
                          <div className="flex items-center space-x-3">
                            {product.image ? (
                              <img src={product.image} alt={product.name} className="w-10 h-10 rounded-lg object-cover" />
                            ) : (
                              <div className="w-10 h-10 bg-gray-300 rounded flex items-center justify-center">
                                <SafeIcon icon={FiIcons.FiBox} className="w-5 h-5 text-gray-500" />
                              </div>
                            )}
                            <div className="flex-1">
                              <h5 className="text-sm font-semibold">{product.name}</h5>
                              {product.price && <p className="text-xs" style={{ color: formData.accentColor }}>{product.price}</p>}
                            </div>
                          </div>
                        </div>
                      ))}
                      {formData.products.length > 3 && (
                        <p className="text-xs text-gray-500 text-center">+{formData.products.length - 3} more products</p>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="bg-white rounded-2xl shadow-xl p-6 space-y-3">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={saveStore}
                  disabled={isSaving}
                  className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-200 flex items-center justify-center space-x-2"
                >
                  {isSaving ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                      <span>Saving...</span>
                    </>
                  ) : (
                    <>
                      <SafeIcon icon={FiIcons.FiSave} />
                      <span>Save Store</span>
                    </>
                  )}
                </motion.button>
                
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={previewStore}
                  className="w-full bg-gray-100 hover:bg-gray-200 text-gray-800 font-semibold py-3 px-6 rounded-lg transition-all duration-200 flex items-center justify-center space-x-2"
                >
                  <SafeIcon icon={FiIcons.FiEye} />
                  <span>Preview Store</span>
                </motion.button>
                
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={exportHTML}
                  className="w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-200 flex items-center justify-center space-x-2"
                >
                  <SafeIcon icon={FiIcons.FiDownload} />
                  <span>Export HTML</span>
                </motion.button>
              </div>

              {/* Stats */}
              <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-6 text-white">
                <h3 className="text-lg font-semibold mb-4">Store Stats</h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-blue-100">Products</span>
                    <span className="font-semibold">{formData.products.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-blue-100">Social Links</span>
                    <span className="font-semibold">{Object.values(formData.socialLinks).filter(Boolean).length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-blue-100">Theme</span>
                    <span className="font-semibold capitalize">{formData.theme}</span>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BuilderPage;