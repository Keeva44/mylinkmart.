import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';

const StorePage = ({ onSupportClick }) => {
  const { username } = useParams();
  const [storeData, setStoreData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [copiedLink, setCopiedLink] = useState(false);

  useEffect(() => {
    const loadStore = () => {
      // Simulate loading delay for better UX
      setTimeout(() => {
        const stores = JSON.parse(localStorage.getItem('mylinkmart_stores') || '{}');
        const store = stores[username];
        
        if (store) {
          setStoreData(store);
        }
        setLoading(false);
      }, 800);
    };

    loadStore();
  }, [username]);

  const copyToClipboard = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  const shareStore = async () => {
    const url = window.location.href;
    const title = `@${storeData.username} - MyLinkMart Store`;

    if (navigator.share) {
      try {
        await navigator.share({ title, url });
      } catch (err) {
        if (err.name !== 'AbortError') {
          await copyToClipboard(url);
        }
      }
    } else {
      await copyToClipboard(url);
    }
  };

  const getSocialIcon = (platform) => {
    const icons = {
      twitter: 'fab fa-twitter',
      instagram: 'fab fa-instagram',
      facebook: 'fab fa-facebook-f',
      linkedin: 'fab fa-linkedin-in',
      tiktok: 'fab fa-tiktok',
      youtube: 'fab fa-youtube',
      pinterest: 'fab fa-pinterest',
      github: 'fab fa-github',
      telegram: 'fab fa-telegram-plane',
      whatsapp: 'fab fa-whatsapp',
      spotify: 'fab fa-spotify'
    };
    return icons[platform] || 'fas fa-link';
  };

  const getThemeClasses = (theme) => {
    switch (theme) {
      case 'dark':
        return 'bg-gray-900 text-white';
      case 'minimal':
        return 'bg-gray-50 text-gray-700';
      case 'gradient':
        return 'gradient-bg text-white';
      default:
        return 'bg-white text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="text-center"
        >
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-gray-600">Loading amazing store...</p>
        </motion.div>
      </div>
    );
  }

  if (!storeData) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center max-w-md mx-auto px-4"
        >
          <div className="w-24 h-24 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-6">
            <SafeIcon icon={FiIcons.FiXCircle} className="w-12 h-12 text-gray-400" />
          </div>
          <h1 className="text-2xl font-bold text-gray-800 mb-4">Store Not Found</h1>
          <p className="text-gray-600 mb-6">
            The store "@{username}" doesn't exist or has been removed.
          </p>
          <a href="#/" className="inline-flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-lg transition-colors duration-200">
            <SafeIcon icon={FiIcons.FiShoppingBag} />
            <span>Create Your Own Store</span>
          </a>
        </motion.div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen py-8 ${getThemeClasses(storeData.theme)}`} style={{ '--accent-color': storeData.accentColor }}>
      <div className="max-w-md mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className={`rounded-2xl shadow-2xl overflow-hidden ${
            storeData.theme === 'dark' 
              ? 'bg-gray-800' 
              : storeData.theme === 'minimal' 
              ? 'bg-white' 
              : storeData.theme === 'gradient' 
              ? 'bg-white bg-opacity-10 backdrop-blur-lg' 
              : 'bg-white'
          }`}
        >
          {/* Banner */}
          <AnimatePresence>
            {storeData.bannerImage && (
              <motion.div
                initial={{ height: 0 }}
                animate={{ height: 'auto' }}
                exit={{ height: 0 }}
                className="h-32 bg-cover bg-center relative"
                style={{ backgroundImage: `url(${storeData.bannerImage})` }}
              >
                <div className="absolute inset-0 bg-black bg-opacity-20"></div>
              </motion.div>
            )}
          </AnimatePresence>
          
          <div className="p-6 text-center">
            {/* Profile Image */}
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: "spring" }}
              className={`relative ${storeData.bannerImage ? '-mt-16' : ''}`}
            >
              <div className="relative inline-block">
                {storeData.profileImage ? (
                  <img 
                    src={storeData.profileImage} 
                    alt="Profile" 
                    className="w-24 h-24 rounded-full border-4 border-white shadow-xl object-cover"
                  />
                ) : (
                  <div className={`w-24 h-24 rounded-full border-4 border-white shadow-xl flex items-center justify-center ${
                    storeData.theme === 'dark' ? 'bg-gray-700' : 'bg-gray-200'
                  }`}>
                    <SafeIcon icon={FiIcons.FiUser} className={`w-8 h-8 ${
                      storeData.theme === 'dark' ? 'text-gray-400' : 'text-gray-500'
                    }`} />
                  </div>
                )}
                <div 
                  className="absolute bottom-0 right-0 w-6 h-6 bg-green-500 rounded-full border-2 border-white"
                ></div>
              </div>
            </motion.div>
            
            {/* Username */}
            <motion.h1 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
              className={`text-2xl font-bold mb-2 ${
                storeData.theme === 'dark' || storeData.theme === 'gradient' ? 'text-white' : 'text-gray-800'
              }`}
            >
              @{storeData.username}
            </motion.h1>
            
            {/* Bio */}
            <AnimatePresence>
              {storeData.bio && (
                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className={`mb-6 ${
                    storeData.theme === 'dark' 
                      ? 'text-gray-300' 
                      : storeData.theme === 'gradient'
                      ? 'text-gray-100'
                      : 'text-gray-600'
                  }`}
                >
                  {storeData.bio}
                </motion.p>
              )}
            </AnimatePresence>
            
            {/* Social Links */}
            <AnimatePresence>
              {Object.entries(storeData.socialLinks).some(([, url]) => url) && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                  className="social-icons mb-6"
                >
                  {Object.entries(storeData.socialLinks).map(([platform, url]) => 
                    url && (
                      <motion.a
                        key={platform}
                        href={url}
                        className={platform}
                        target="_blank"
                        rel="noopener noreferrer"
                        aria-label={platform}
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                      >
                        <i className={getSocialIcon(platform)}></i>
                      </motion.a>
                    )
                  )}
                </motion.div>
              )}
            </AnimatePresence>
            
            {/* Products */}
            <div className="space-y-3">
              <AnimatePresence>
                {storeData.products.map((product, index) => (
                  <motion.a
                    key={product.id || index}
                    href={product.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.1 * index }}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className={`block rounded-xl p-4 transition-all duration-200 ${
                      storeData.theme === 'dark' 
                        ? 'bg-gray-700 hover:bg-gray-600' 
                        : storeData.theme === 'gradient'
                        ? 'bg-white bg-opacity-20 hover:bg-opacity-30 backdrop-blur-sm'
                        : 'bg-gray-50 hover:bg-gray-100'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      {/* Product Image */}
                      <motion.div
                        whileHover={{ scale: 1.1 }}
                        className="flex-shrink-0"
                      >
                        {product.image ? (
                          <img 
                            src={product.image} 
                            alt={product.name} 
                            className="w-12 h-12 rounded-lg object-cover"
                          />
                        ) : (
                          <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                            storeData.theme === 'dark' ? 'bg-gray-600' : 'bg-gray-300'
                          }`}>
                            <SafeIcon icon={FiIcons.FiBox} className={`w-6 h-6 ${
                              storeData.theme === 'dark' ? 'text-gray-400' : 'text-gray-500'
                            }`} />
                          </div>
                        )}
                      </motion.div>
                      
                      {/* Product Info */}
                      <div className="flex-1 text-left">
                        <h3 className={`font-semibold ${
                          storeData.theme === 'dark' || storeData.theme === 'gradient' ? 'text-white' : 'text-gray-800'
                        }`}>
                          {product.name}
                        </h3>
                        {product.description && (
                          <p className={`text-sm line-clamp-2 ${
                            storeData.theme === 'dark' 
                              ? 'text-gray-300' 
                              : storeData.theme === 'gradient'
                              ? 'text-gray-100'
                              : 'text-gray-600'
                          }`}>
                            {product.description}
                          </p>
                        )}
                        {product.price && (
                          <p className="text-sm font-semibold mt-1" style={{ color: storeData.accentColor }}>
                            {product.price}
                          </p>
                        )}
                      </div>
                      
                      {/* External Link Icon */}
                      <motion.div
                        whileHover={{ x: 2 }}
                        className={`${
                          storeData.theme === 'dark' 
                            ? 'text-gray-400' 
                            : storeData.theme === 'gradient'
                            ? 'text-gray-200'
                            : 'text-gray-400'
                        }`}
                      >
                        <SafeIcon icon={FiIcons.FiExternalLink} className="w-5 h-5" />
                      </motion.div>
                    </div>
                  </motion.a>
                ))}
              </AnimatePresence>
            </div>
          </div>
          
          {/* Footer */}
          <div className={`px-6 py-4 text-center border-t ${
            storeData.theme === 'dark' 
              ? 'bg-gray-800 border-gray-700' 
              : storeData.theme === 'gradient'
              ? 'bg-white bg-opacity-10 border-white border-opacity-20'
              : 'bg-gray-50 border-gray-200'
          }`}>
            <p className={`text-sm mb-2 ${
              storeData.theme === 'dark' 
                ? 'text-gray-400' 
                : storeData.theme === 'gradient'
                ? 'text-gray-200'
                : 'text-gray-500'
            }`}>
              Built with ❤️ using{' '}
              <a 
                href="#/" 
                className={`hover:underline ${
                  storeData.theme === 'gradient' ? 'text-yellow-300' : 'text-blue-600'
                }`}
              >
                MyLinkMart
              </a>
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={onSupportClick}
              className={`text-sm font-medium transition-colors duration-200 flex items-center justify-center space-x-1 mx-auto ${
                storeData.theme === 'dark'
                  ? 'text-pink-400 hover:text-pink-300'
                  : storeData.theme === 'gradient'
                  ? 'text-yellow-300 hover:text-yellow-200'
                  : 'text-pink-600 hover:text-pink-700'
              }`}
            >
              <SafeIcon icon={FiIcons.FiHeart} />
              <span>💖 Support MyLinkMart Project</span>
            </motion.button>
          </div>
        </motion.div>

        {/* Share Button */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="mt-6 text-center"
        >
          <div className="inline-flex items-center space-x-2 bg-white rounded-full shadow-lg px-4 py-2">
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={shareStore}
              className="bg-gray-100 hover:bg-gray-200 text-gray-700 p-2 rounded-full transition-colors duration-200"
            >
              {copiedLink ? (
                <SafeIcon icon={FiIcons.FiCheck} className="w-5 h-5 text-green-600" />
              ) : (
                <SafeIcon icon={FiIcons.FiShare2} className="w-5 h-5" />
              )}
            </motion.button>
            <span className="text-sm text-gray-600">
              {copiedLink ? 'Link copied!' : 'Share store'}
            </span>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default StorePage;