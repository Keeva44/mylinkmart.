import React from 'react';

const DonationModal = ({ isOpen, onClose, showToast }) => {
  if (!isOpen) return null;

  const copyDetails = () => {
    const details = `💖 Support MyLinkMart Project

📱 Airtel Money: 0750463854

🏦 Bank: Lead Bank
Account Number: 216858671770
Routing Number: 101019644`;

    navigator.clipboard.writeText(details).then(() => {
      showToast('Payment details copied to clipboard! Thank you for your support! 💖', 'success');
      onClose();
    }).catch(() => {
      showToast('Failed to copy details. Please copy manually.', 'error');
    });
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-md w-full p-6 slide-up">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-gray-800">💖 Support MyLinkMart Project</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors duration-200"
          >
            <i className="fas fa-times text-xl"></i>
          </button>
        </div>

        <div className="mb-6">
          <p className="text-gray-600 mb-4">
            Help keep this free for creators worldwide!
          </p>

          <div className="space-y-4">
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <div className="flex items-center mb-2">
                <i className="fas fa-mobile-alt text-green-600 mr-2"></i>
                <span className="font-semibold text-green-800">Airtel Money</span>
              </div>
              <p className="text-green-700 font-mono text-lg">0750463854</p>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-center mb-2">
                <i className="fas fa-university text-blue-600 mr-2"></i>
                <span className="font-semibold text-blue-800">Lead Bank</span>
              </div>
              <div className="text-blue-700">
                <p><span className="font-semibold">Account:</span> 216858671770</p>
                <p><span className="font-semibold">Routing:</span> 101019644</p>
              </div>
            </div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <button
            onClick={copyDetails}
            className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-4 rounded-lg transition-all duration-200 flex items-center justify-center space-x-2"
          >
            <i className="fas fa-copy"></i>
            <span>Copy Details</span>
          </button>
          <button
            onClick={onClose}
            className="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-800 font-semibold py-3 px-4 rounded-lg transition-all duration-200"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default DonationModal;