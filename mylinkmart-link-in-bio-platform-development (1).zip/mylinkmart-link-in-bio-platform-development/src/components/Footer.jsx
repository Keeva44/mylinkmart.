import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';

const Footer = ({ onSupportClick }) => {
  const currentYear = new Date().getFullYear();

  const footerLinks = [
    { to: '/', label: 'Home', icon: FiIcons.FiHome },
    { to: '/builder', label: 'Create Store', icon: FiIcons.FiPlus },
    { onClick: onSupportClick, label: 'Support Us', icon: FiIcons.FiHeart }
  ];

  const features = [
    'Link-in-Bio Pages',
    'Affiliate Products',
    'Social Media Links',
    'Custom Themes',
    'Mobile Responsive',
    'Export HTML'
  ];

  return (
    <footer className="bg-gray-900 text-white relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-0 left-0 w-64 h-64 bg-blue-500 rounded-full filter blur-3xl"></div>
        <div className="absolute bottom-0 right-0 w-64 h-64 bg-purple-500 rounded-full filter blur-3xl"></div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="col-span-1 md:col-span-2"
          >
            <div className="flex items-center space-x-2 mb-4">
              <motion.div
                whileHover={{ rotate: 360 }}
                transition={{ duration: 0.5 }}
                className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center"
              >
                <SafeIcon icon={FiIcons.FiShoppingBag} className="text-white text-sm" />
              </motion.div>
              <span className="text-xl font-bold">MyLinkMart</span>
            </div>
            <p className="text-gray-400 mb-6 max-w-md leading-relaxed">
              Turn your bio into a mini affiliate store. Create beautiful link-in-bio pages 
              with products, social links, and more - completely free forever.
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={onSupportClick}
              className="inline-flex items-center space-x-2 text-pink-400 hover:text-pink-300 transition-colors duration-200 group"
            >
              <SafeIcon icon={FiIcons.FiHeart} className="group-hover:animate-pulse" />
              <span>Support MyLinkMart Project</span>
            </motion.button>
          </motion.div>

          {/* Quick Links */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
          >
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-3">
              {footerLinks.map((link, index) => (
                <li key={index}>
                  {link.to ? (
                    <Link
                      to={link.to}
                      className="flex items-center space-x-2 text-gray-400 hover:text-white transition-colors duration-200 group"
                    >
                      <SafeIcon icon={link.icon} className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                      <span>{link.label}</span>
                    </Link>
                  ) : (
                    <button
                      onClick={link.onClick}
                      className="flex items-center space-x-2 text-gray-400 hover:text-white transition-colors duration-200 group"
                    >
                      <SafeIcon icon={link.icon} className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                      <span>{link.label}</span>
                    </button>
                  )}
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Features */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
          >
            <h3 className="text-lg font-semibold mb-4">Features</h3>
            <ul className="space-y-2">
              {features.map((feature, index) => (
                <li key={index} className="flex items-center space-x-2 text-gray-400">
                  <SafeIcon icon={FiIcons.FiCheck} className="w-3 h-3 text-green-400" />
                  <span>{feature}</span>
                </li>
              ))}
            </ul>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3 }}
          className="border-t border-gray-800 mt-12 pt-8"
        >
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm mb-4 md:mb-0">
              © {currentYear} MyLinkMart. Built with ❤️ for creators worldwide.
            </p>
            <div className="flex items-center space-x-4">
              <span className="text-gray-400 text-sm">Made with</span>
              <motion.div
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 1, repeat: Infinity }}
              >
                <SafeIcon icon={FiIcons.FiHeart} className="text-red-500 w-4 h-4" />
              </motion.div>
              <span className="text-gray-400 text-sm">using MyLinkMart</span>
            </div>
          </div>
        </motion.div>
      </div>
    </footer>
  );
};

export default Footer;