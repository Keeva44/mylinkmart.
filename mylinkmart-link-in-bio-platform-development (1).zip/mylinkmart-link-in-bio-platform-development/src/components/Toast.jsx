import React from 'react';

const Toast = ({ show, message, type = 'success' }) => {
  if (!show) return null;

  const bgColor = type === 'success' ? 'bg-green-500' : 'bg-red-500';
  const icon = type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle';

  return (
    <div className="fixed top-4 right-4 z-50 slide-up">
      <div className={`${bgColor} text-white px-6 py-3 rounded-lg shadow-lg flex items-center space-x-3 max-w-sm`}>
        <i className={`fas ${icon}`}></i>
        <span className="text-sm font-medium">{message}</span>
      </div>
    </div>
  );
};

export default Toast;