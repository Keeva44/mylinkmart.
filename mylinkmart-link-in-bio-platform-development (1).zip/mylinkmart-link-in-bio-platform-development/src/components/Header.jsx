import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';

const Header = ({ onSupportClick }) => {
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  return (
    <header className="sticky top-0 z-50 bg-white shadow-sm border-b border-gray-200 backdrop-blur-lg bg-opacity-95">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center space-x-2 group">
            <motion.div
              whileHover={{ rotate: 360 }}
              transition={{ duration: 0.5 }}
              className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center"
            >
              <SafeIcon icon={FiIcons.FiShoppingBag} className="text-white text-sm" />
            </motion.div>
            <span className="text-xl font-bold gradient-text">MyLinkMart</span>
          </Link>

          <nav className="hidden md:flex items-center space-x-6">
            {[
              { path: '/', label: 'Home', icon: FiIcons.FiHome },
              { path: '/builder', label: 'Builder', icon: FiIcons.FiEdit }
            ].map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center space-x-1 text-sm font-medium transition-colors duration-200 ${
                  location.pathname === item.path
                    ? 'text-blue-600'
                    : 'text-gray-600 hover:text-blue-600'
                }`}
              >
                <SafeIcon icon={item.icon} className="w-4 h-4" />
                <span>{item.label}</span>
              </Link>
            ))}
            <button
              onClick={onSupportClick}
              className="flex items-center space-x-1 text-sm font-medium text-pink-600 hover:text-pink-700 transition-colors duration-200"
            >
              <SafeIcon icon={FiIcons.FiHeart} />
              <span>Support Us</span>
            </button>
          </nav>

          <div className="flex items-center space-x-4">
            <Link 
              to="/builder" 
              className="hidden sm:flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg transition-all duration-200 transform hover:scale-105"
            >
              <SafeIcon icon={FiIcons.FiPlus} className="w-4 h-4" />
              <span>Create Store</span>
            </Link>

            {/* Mobile menu button */}
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden text-gray-600 hover:text-blue-600"
            >
              {mobileMenuOpen ? (
                <SafeIcon icon={FiIcons.FiX} className="w-6 h-6" />
              ) : (
                <SafeIcon icon={FiIcons.FiMenu} className="w-6 h-6" />
              )}
            </motion.button>
          </div>
        </div>

        {/* Mobile menu */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden py-4 border-t border-gray-200"
            >
              <div className="flex flex-col space-y-3">
                <Link
                  to="/"
                  className={`flex items-center space-x-2 text-sm font-medium px-3 py-2 rounded-lg transition-colors duration-200 ${
                    location.pathname === '/'
                      ? 'bg-blue-50 text-blue-600'
                      : 'text-gray-600 hover:bg-gray-50'
                  }`}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <SafeIcon icon={FiIcons.FiHome} className="w-4 h-4" />
                  <span>Home</span>
                </Link>
                <Link
                  to="/builder"
                  className={`flex items-center space-x-2 text-sm font-medium px-3 py-2 rounded-lg transition-colors duration-200 ${
                    location.pathname === '/builder'
                      ? 'bg-blue-50 text-blue-600'
                      : 'text-gray-600 hover:bg-gray-50'
                  }`}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <SafeIcon icon={FiIcons.FiEdit} className="w-4 h-4" />
                  <span>Builder</span>
                </Link>
                <button
                  onClick={() => {
                    onSupportClick();
                    setMobileMenuOpen(false);
                  }}
                  className="flex items-center space-x-2 text-sm font-medium px-3 py-2 rounded-lg text-pink-600 hover:bg-pink-50 transition-colors duration-200"
                >
                  <SafeIcon icon={FiIcons.FiHeart} />
                  <span>Support Us</span>
                </button>
                <Link
                  to="/builder"
                  className="flex items-center justify-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg transition-all duration-200"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <SafeIcon icon={FiIcons.FiPlus} className="w-4 h-4" />
                  <span>Create Store</span>
                </Link>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </header>
  );
};

export default Header;