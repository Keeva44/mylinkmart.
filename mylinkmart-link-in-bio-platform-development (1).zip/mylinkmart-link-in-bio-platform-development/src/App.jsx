import React, { useState, useEffect } from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import LandingPage from './pages/LandingPage';
import BuilderPage from './pages/BuilderPage';
import StorePage from './pages/StorePage';
import Header from './components/Header';
import Footer from './components/Footer';
import DonationModal from './components/DonationModal';
import Toast from './components/Toast';
import './App.css';

function App() {
  const [showDonationModal, setShowDonationModal] = useState(false);
  const [toast, setToast] = useState({ show: false, message: '', type: 'success' });

  const showToast = (message, type = 'success') => {
    setToast({ show: true, message, type });
    setTimeout(() => setToast({ show: false, message: '', type: 'success' }), 3000);
  };

  useEffect(() => {
    // Initialize local storage if needed
    if (!localStorage.getItem('mylinkmart_stores')) {
      localStorage.setItem('mylinkmart_stores', JSON.stringify({}));
    }
  }, []);

  return (
    <Router>
      <div className="min-h-screen bg-gray-50 flex flex-col">
        <Header onSupportClick={() => setShowDonationModal(true)} />
        
        <main className="flex-1">
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/builder" element={<BuilderPage showToast={showToast} />} />
            <Route path="/store/:username" element={<StorePage onSupportClick={() => setShowDonationModal(true)} />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>

        <Footer onSupportClick={() => setShowDonationModal(true)} />

        <DonationModal 
          isOpen={showDonationModal}
          onClose={() => setShowDonationModal(false)}
          showToast={showToast}
        />

        <Toast 
          show={toast.show}
          message={toast.message}
          type={toast.type}
        />
      </div>
    </Router>
  );
}

export default App;